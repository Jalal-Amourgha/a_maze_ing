_This project has been created as part of the 42 curriculum by jamourgh & aarid_

# Maze Generator Project

# Description
A maze generation project using DFS and Prim's algorithms to generate a full cool maze with several features, that can be toggle from the menu, which demonstrate the understanding of a graph structure...

# Instructions


## Installation
**For a normal usage u can just use the `make` from makefile
to generate the main maze**

***For usage from the generator package, u'll find the already build package name "mazegen-0.0.1-py3-none-any.whl" u can easily install it with pip:***


```bash
pip install mazegen-0.0.1-py3-none-any.whl
```

## Usage (Package Documentation)
### Instantiate the generator

```python
from mazegen.generator import MazeGenerator

maze = MazeGenerator(
    width=10,
    height=10,
    entry=(0, 0),
    exit=(9, 9),
    output_filename="maze.txt",
    perfect=True,
    seed=42
)
```

### Generate a maze

```python
maze.ft_generate_maze_DFS()  # or ft_generate_maze_prims()
```

### Access the maze structure

```python
maze.maze  # 2D list of cell walls (bitmask format)
# N=1, E=2, S=4, W=8
# Example: maze[0][0] = 12 means South and West walls
```

Then u can play with rest functionality by yourself.

## Building the Package
**If u decide to build the package yourself, u should install the builder "build" from pip, then after configuring the pyproject.toml to use which backend tool u prefer, you can go and build the composite builded package, if you decide to use the setuptool for the backend u should install the wheel for pip also, otherwise if u going with poetry, its will take care for the rest.**


```bash
# Install build tools
pip install build

# Build the package
python -m build
```

## Project Structure
- `mazegen/` - The reusable package
- `a_maze_ing.py` - Main program
- `pyproject.toml` - Build configuration
- ...

# Resources
- Helpful resources::
Prime algo => https://weblog.jamisbuck.org/2011/1/10/maze-generation-prim-s-algorithm
backtracking =>  https://youtu.be/DKCbsiDBN6c?si=zz776xEgTTaSJGbX 


- Ai usage:: The ai also was a very helpful to break the complex concepts, with an quick simple analogies, Also its can reference you to another very good quality resources



### Config file
***Structure and format of config file***


| Key                      | Purpose                                           |
| ------------------------ | ------------------------------------------------- |
| `WIDTH`                  | Width of the maze                                 |
| `HEIGHT`                 | Height of maze                                    |
| `ENTRY`                  | Entry point (start) of the path                   |
| `EXIT`                   | Exit point (end) of the path                      |
| `OUTPUT_FILE`            | Filename to write the maze into                   |
| `PERFECT`                | Condition for generating one path or more         |
| `SEED`                   | starting point for randomising to predict the maze|
|
### maze algorithms
***For the generation we use DFS, Prims***
***For solution we chose BFS***

*The reason behind the chosen was about the opportunity, since that about the maze
which kinda represent the structure of the graph concept, we its a very good opportunity to learn about that concept with its most popular algorithms.*

***The module mazegen is full reusable with all functions needed, with easy and simple usage:***


```python
	>>> maze = MazeGenerator(
	...     width=10,
	...     height=10,
	...     entry=(0, 0),
	...     exit=(9, 9),
	...     output_filename="maze.txt",
	...     perfect=True,
	...     seed=42
	... )
	>>> maze.ft_generate_maze_DFS()
	>>> ft_generate_output_file()
	>>> ft_print_maze_animation("", True)
    >>> maze.ft_maze_options()
```


### Team and project management
- `jamourgh` == Build and define the logic code for the full maze with the general and advance features.

- `aarid` == Maintain the structure of the full project, form the reusable package, with organizing and cleaning the project.

### Work planing
*We follow an organized full roadmap for each one with his specific tasks, and the collaboration was smooth, and professional*

### Can Improved
Maybe the complexity between the generation and solution algorithms can improved more for a better merge between the two approach, otherwise the main features is acceptable.

### Specific tool
I can say that we add some little touches by PIL library, It was a small feature that help for adding some effects.
